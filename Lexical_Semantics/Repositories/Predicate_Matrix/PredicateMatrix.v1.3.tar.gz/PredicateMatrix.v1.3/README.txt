
Predicate Matrix v1.3
---------------------

Version v1.3 of the Predicate Matrix has been partially funded by 
TUNER (TIN2015-65308-C5-1-R) and NewsReader (FP7-ICT-2011-8-316404), 
as well as the READERS project with the financial support of MINECO, 
ANR (convention ANR-12-CHRI-0004-03) and EPSRC (EP/K017845/1) in the 
framework of ERA-NET CHIST-ERA (UE FP7/2007-2013)

The Predicate Matrix v1.3 is a lexical multilingual resource resulting from 
the integration of multiple sources of predicate information including
FrameNet, VerbNet, PropBank, WordNet, NomBank, ESO, AnCora and Basque Verb Index.

The current version of the Predicate Matrix includes verbal predicates for 
English, Spanish, Basque and Catalan, as well as nominalizations for English
and Spanish. 
Each row of this Predicate Matrix represents the mapping of a role
over the different resources and includes all the aligned knowledge about
its corresponding verb sense. The current version of the Predicate Matrix 
also includes ontological knowledge from the Multilingual Central Repositor
(MCR). 
Each row is indetified by the unique index formed by the first four columns.

The current content of the Predicate Matrix v1.3 can be consulted in 
http://adimen.si.ehu.es/web/PredicateMatrix

For more details on the Predicate Matrix v1.3, please consult the 
following paper:

López de Lacalle M., Laparra E., Aldabe I. and Rigau G. 
A Multilingual Predicate Matrix. Proceedings of the 10th international 
conference on Language Resources and Evaluation (LREC 2016). 
Portoroẑ, Slovenia. 2016.

Contents of the distribution
----------------------------

PredicateMatrix.v1.3.txt		Predicate Matrix file
README.txt				README file

License
-------

This package is distributed under Attribution 3.0 Unported (CC BY 3.0) license. You can find it at http://creativecommons.org/licenses/by/3.0

File description of the Predicate Matrix v1.3
---------------------------------------------

Each row of the Predicate Matrix represents the mapping of
a role over the different resources and includes all the 
aligned knowledge about its corresponding verb.

The Predicate Matrix v1.3 file is structured in 27 columns. The first four 
form the index of the row:

- 1_ID_LANG: this column contains the language of the predicate.

- 2_ID_POS: this columnn contains the part-of-speech of the predicate.

- 3_ID_PRED: this column contains the predicate.

- 4_ID_ROLE: this column contains the role.

- 5_VN_CLASS: this column contains the information of the VerbNet class.

- 6_VN_CLASS_NUMBER: this column contains the information of the VerbNet 
class number.

- 7_VN_SUBCLASS: this column contains the information of VerbNet subclass.

- 8_VN_SUBCLASS_NUMBER: this column contains the information of the VerbNet 
subclass number.

- 9_VN_LEMA: this column contains the information of the verb lemma.

- 10_VN_ROLE: this column contains the information of the VerbNet thematic-role.

- 11_WN_SENSE: this column contains the information of the word sense in WordNet. 

- 12_MCR_iliOffset: this column contains the information of the ILI number
 in the MCR3.0.

- 13_FN_FRAME: this column contains the information of the frame in FrameNet.

- 14_FN_LE: this column contains the information of the corresponding 
lexical-entry in FrameNet.

- 15_FN_FRAME_ELEMENT: this column contains the information of 
the frame-element in FrameNet.

- 16_PB_ROLESET: this column contains the information of 
the predicate in PropBank.

- 17_PB_ARG: this column contains the information of the predicate
 argument in PropBank.

- 18_MCR_BC: this column contains the information if the verb sense 
it is Base Concept or not in the MCR3.0.

- 19_MCR_DOMAIN: this column contains the information of the WordNet domain
aligned to WordNet 3.0 in the MCR3.0.

- 20_MCR_SUMO: this column contains the information of the AdimenSUMO in the MCR3.0.

- 21_MCR_TO: this column contains the information of the MCR Top Ontology in the MCR3.0.
 
- 22_MCR_LEXNAME: this column contains the information of the MCR Lexicographical file name.

- 23_MCR_BLC: this column contains the information of the Base Level Concept 
of the WordNet verb sense in the MCR3.0.

- 24_WN_SENSEFREC: this column contains the information of the frecuency of the
WordNet 3.0 verb sense.

- 25_WN_SYNSET_REL_NUM: this column contains the information of the number of 
relations of the WordNet 3.0 verb sense.

- 26_ESO_CLASS: this column contains the information of the class of the ESO ontology.

- 27_ESO_ROLE: this column contains the information of the role of the ESO ontology.

Additional information
----------------------

Ongoing development work on the Predicate Matrix is done by a small group of
researchers. Since our resources are VERY limited, we request that
you please confine correspondence to the Predicate Matrix topics only. Please
check carefully this documentation and other resources to answer
to your question or problem before contacting us.

SemLink:
http://verbs.colorado.edu/semlink/

English Princeton WordNet:
http://wordnet.princeton.edu

VerbNet:
http://verbs.colorado.edu/~mpalmer/projects/verbnet.html

FrameNet:
https://framenet.icsi.berkeley.edu

PropBank:
http://verbs.colorado.edu/~mpalmer/projects/ace.html

NomBank:
http://nlp.cs.nyu.edu/meyers/NomBank.html

AnCora:
http://clic.ub.edu/corpus/es/ancora

Basque Verb Index:
http://ixa2.si.ehu.es/e-rolda/en/bvi.php

ESO:
http://www.newsreader-project.eu/results/event-and-situation-ontology/

AdimenSUMO:
http://adimen.si.ehu.es/web/adimenSUMO

Multilingual Central Repository:
http://adimen.si.ehu.es/web/MCR

Predicate Matrix:
http://adimen.si.ehu.es/web/PredicateMatrix

NewsReader project:
http://www.newsreader-project.eu/

Research groups involved
------------------------

IXA	http://ixa.si.ehu.es

Contact information
-------------------

German Rigau
IXA Group
University of the Basque Country
E-20018 San Sebastián

german.rigau AT ehu.com






